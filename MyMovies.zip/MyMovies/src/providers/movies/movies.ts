import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the MoviesProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class MoviesProvider {

  private apiKey = '60b8c8663c5b8544a67b2192f513891f';

  constructor(private http: HttpClient) {
    console.log('Hello MoviesProvider Provider');
  }

  getPopularMovies() {
    const url = `https://api.themoviedb.org/3/movie/popular?page=1&language=pt-BR&api_key=${this.apiKey}`;

    return this.http.get(url);
  }

}
