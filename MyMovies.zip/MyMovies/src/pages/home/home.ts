import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MoviesProvider } from '../../providers/movies/movies';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers: [
    MoviesProvider
  ]
})
export class HomePage {

  public listaFilmes = new Array<any>();
  public prefixUrl: string = 'http://image.tmdb.org/t/p/w300'

  constructor(public navCtrl: NavController,
    private moviesProvider: MoviesProvider) {

  }
  
  ionViewDidLoad() {
    this.buscaFilmesPopulares();
  }

  buscaFilmesPopulares() {
    this.moviesProvider.getPopularMovies()
      .subscribe(data => {
        const retorno = (data as any);
        this.listaFilmes = retorno.results;
        console.log(this.listaFilmes)
      }, error => {
        console.log(error);
      });
  }
}
